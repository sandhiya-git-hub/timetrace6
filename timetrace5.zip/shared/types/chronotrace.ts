export type AppScreen = 'splash' | 'auth' | 'app';

export type PrimaryNavTab = 'dashboard' | 'timeline' | 'raw' | 'assistant';

export type IntentLabel =
  | 'DEEP_WORK'
  | 'LEARNING'
  | 'COLLABORATION'
  | 'COMMUNICATION'
  | 'ADMIN'
  | 'DISTRACTION'
  | 'DISTRACTION_BREAK'
  | string;

export interface UserProfile {
  id: string;
  username: string;
  email: string;
  name: string;
  givenName?: string;
  picture?: string;
  deviceToken: string;
  emailVerified?: boolean;
  lastLogin?: string;
  isRegistered?: boolean;
  hasConfiguredDevice?: boolean;
}

export interface DeviceState {
  connected: boolean;
  status:
    | 'CONNECTED'
    | 'CONNECTED_AWAITING_ACTIVITY'
    | 'RECONNECTING'
    | 'DISCONNECTED'
    | 'NOT_CONNECTED'
    | 'ERROR'
    | string;
  paused: boolean;
  deviceName: string;
  os: string;
  agentVersion: string;
  samplingInterval: string;
  lastEventTime: string | null;
  lastLocalDate: string;
  eventCount: number;
  statusText: string;
  lastPing?: string | null;
  lastHeartbeatAt?: string | null;
  connectedSince?: string | null;
  lastSuccessfulConnectionAt?: string | null;
  currentWindowTitle?: string | null;
  currentForegroundApp?: string | null;
}

export interface TelemetryEvent {
  id?: string;
  timestamp: string;
  date?: string;
  recorded_at?: string;
  app_name: string;
  window_title: string;
  category: string;
  dwell_ms: number;
  key_count?: number;
  keys?: number;
  keyboard_events?: number;
}

export interface SubEvent {
  app: string;
  title: string;
  dwell_s: number;
  keys?: number;
}

export interface ChunkSummary {
  chunk_id: string;
  recorded_at?: string;
  localDate?: string;
  duration_s: number;
  start_time: string;
  end_time: string;
  closed_by?: string;
  main_events: SubEvent[];
  anchor_app: string;
  anchor_held_s?: number;
  returned_to_anchor?: boolean;
  keyboard?: {
    total_keys: number;
    rate_per_min: number;
  };
  micro_behavior?: {
    total_rapid_switches: number;
    tab_flickers: number;
    avg_micro_dwell_ms: number;
    dominant_pattern: string;
    unique_micro_apps: string[];
  };
  categories_present?: string[];
  dominant_category?: string;
  copy_paste_events?: number;
  session_start_restless?: boolean;
  intent?: IntentLabel;
  confidence?: number;
  primary_task?: string;
  distraction_detected?: boolean;
  distraction_type?: string | null;
  work_state?: string;
  unresolved_threads?: string[];
  summary?: string;
  user_corrected?: boolean;
}

export interface DailySynthesis {
  date: string;
  total_deep_work_s: number;
  total_distraction_s: number;
  total_telemetry_s: number;
  fragmentation_score: number;
  peak_focus_window: string;
  context_switches: number;
  distraction_triggers: string[];
  daily_narrative: string;
  unfinished_work?: string[];
  work_state?: string;
  stat_sub?: {
    deep_work?: string;
    distraction?: string;
    context_switches?: string;
    work_state?: string;
  };
  range?: string;
  longest_session_s?: number;
  longest_session_app?: string;
  avg_dwell_per_switch_s?: number;
  top_app_today?: { name: string; dwell_s: number };
  tracked_days_count?: number;
  deep_work_ratio?: number;
  distraction_ratio?: number;
}

export interface ReentryBriefing {
  project?: string;
  found?: boolean;
  days_ago?: number;
  time_desc?: string;
  headline?: string;
  primary_task?: string;
  summary?: string;
  unresolved_threads?: string[];
  last_session?: ChunkSummary;
}

export interface ChatMessage {
  id?: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp?: string;
  suggestedFollowUps?: string[];
}
