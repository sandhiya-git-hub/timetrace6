import express from 'express';
import bcrypt from 'bcryptjs';
import path from 'path';
import fs from 'fs';
import { ai, AGENT_FILE } from '../config/env.js';
import type { ChunkSummary, DailySynthesis, TelemetryEvent, DeviceState } from '../../../shared/types/chronotrace.js';
import type { UserRecord, AuthSession, DeviceRecord } from '../types/models.js';
import { getUsers, saveUsers, getAuthSessions, saveAuthSessions } from '../services/userStore.js';
import { getUserDir, defaultDeviceRecord, HEARTBEAT_TIMEOUT_MS, isAgentLive, getUserDeviceRecord, saveUserDeviceRecord, getUserTelemetry, saveUserTelemetry, getUserSessions, saveUserSessions, getUserSummary, saveUserSummary } from '../services/dataStore.js';
import { getSessionToken, getAuthenticatedUser, createSessionForUser, toUserProfile, toDeviceStatus } from '../services/authHelpers.js';

const router = express.Router();

// -------------------------------------------------------------
// USER DATA & ANALYTICS API ENDPOINTS
// -------------------------------------------------------------

router.get('/api/telemetry/raw', (req, res) => {
  const user = res.locals.user as UserRecord;
  let list = getUserTelemetry(user.id);

  const { search, category, page = '1', limit = '50', sort = 'newest' } = req.query as {
    search?: string;
    category?: string;
    page?: string;
    limit?: string;
    sort?: string;
  };

  if (category && category !== 'ALL') {
    list = list.filter((e) => e.category?.toLowerCase() === category.toLowerCase());
  }

  if (search && search.trim()) {
    const q = search.trim().toLowerCase();
    list = list.filter(
      (e) =>
        e.app_name?.toLowerCase().includes(q) ||
        e.window_title?.toLowerCase().includes(q) ||
        e.category?.toLowerCase().includes(q)
    );
  }

  if (sort !== 'oldest') {
    list = [...list].reverse();
  }

  const pageNum = Math.max(1, parseInt(page, 10) || 1);
  const pageSize = Math.max(1, Math.min(200, parseInt(limit, 10) || 50));
  const total = list.length;
  const totalPages = Math.ceil(total / pageSize) || 1;
  const paginated = list.slice((pageNum - 1) * pageSize, pageNum * pageSize);

  res.json({
    events: paginated,
    total,
    page: pageNum,
    pageSize,
    totalPages,
  });
});

router.get(['/api/sessions', '/sessions', '/sessions/today'], (req, res) => {
  const user = res.locals.user as UserRecord;
  let sessions = getUserSessions(user.id);
  const rec = getUserDeviceRecord(user.id);

  const { category, search, date, startDate, endDate } = req.query as {
    category?: string;
    search?: string;
    date?: string;
    startDate?: string;
    endDate?: string;
  };

  const isTodayOnly = req.path.includes('today') || date;
  if (isTodayOnly) {
    const targetDate = date || rec.lastLocalDate || new Date().toISOString().split('T')[0];
    sessions = sessions.filter((s) => {
      const sDate = s.localDate || (s.recorded_at ? s.recorded_at.split('T')[0] : targetDate);
      return sDate === targetDate;
    });
  } else if (startDate && endDate) {
    sessions = sessions.filter((s) => {
      const sDate = s.localDate || (s.recorded_at ? s.recorded_at.split('T')[0] : '');
      return sDate ? (sDate >= startDate && sDate <= endDate) : true;
    });
  }

  if (category && category !== 'ALL') {
    sessions = sessions.filter((s) => s.dominant_category?.toLowerCase() === category.toLowerCase() || s.intent?.toLowerCase() === category.toLowerCase());
  }

  if (search && search.trim()) {
    const q = search.trim().toLowerCase();
    sessions = sessions.filter(
      (s) =>
        s.primary_task?.toLowerCase().includes(q) ||
        s.summary?.toLowerCase().includes(q) ||
        s.anchor_app?.toLowerCase().includes(q) ||
        s.main_events?.some((e) => e.title?.toLowerCase().includes(q) || e.app?.toLowerCase().includes(q))
    );
  }

  res.json(sessions);
});

router.get(['/api/summary', '/summary', '/api/summary/today', '/summary/today'], (req, res) => {
  const user = res.locals.user as UserRecord;
  const allTelemetry = getUserTelemetry(user.id);
  const allSessions = getUserSessions(user.id);
  const rec = getUserDeviceRecord(user.id);

  const { range, startDate, endDate, date } = req.query as {
    range?: string;
    startDate?: string;
    endDate?: string;
    date?: string;
  };

  const todayStr = rec.lastLocalDate || (allTelemetry.length > 0 ? allTelemetry[allTelemetry.length - 1].date : null) || new Date().toISOString().split('T')[0];

  // Scope telemetry and sessions to target date or date range
  let telemetry = allTelemetry;
  let sessions = allSessions;

  const isTodayOnly = range === 'today' || req.path.includes('today') || (!range && !startDate && !endDate);
  if (isTodayOnly) {
    const targetDate = date || startDate || todayStr;
    telemetry = allTelemetry.filter((e) => e.date === targetDate);
    sessions = allSessions.filter((s) => {
      const sDate = s.localDate || (s.recorded_at ? s.recorded_at.split('T')[0] : todayStr);
      return sDate === targetDate;
    });
  } else if (startDate && endDate) {
    telemetry = allTelemetry.filter((e) => e.date ? (e.date >= startDate && e.date <= endDate) : true);
    sessions = allSessions.filter((s) => {
      const sDate = s.localDate || (s.recorded_at ? s.recorded_at.split('T')[0] : todayStr);
      return sDate ? (sDate >= startDate && sDate <= endDate) : true;
    });
  }

  let deepWorkSec = 0;
  let distractionSec = 0;
  let totalSec = 0;
  let switches = 0;
  const triggers: Set<string> = new Set();
  const appDwells: Record<string, number> = {};

  for (let i = 0; i < telemetry.length; i++) {
    const ev = telemetry[i];
    const sec = Math.max(1, Math.round((ev.dwell_ms || 2000) / 1000));
    totalSec += sec;

    const cat = ev.category || 'Utility';
    if (cat === 'Deep Work' || cat === 'Learning') {
      deepWorkSec += sec;
    } else if (cat === 'Distraction' || cat === 'Entertainment') {
      distractionSec += sec;
      if (ev.window_title && !ev.window_title.includes('ChronoTrace')) {
        triggers.add(ev.window_title.slice(0, 45));
      }
    }

    if (ev.app_name) {
      appDwells[ev.app_name] = (appDwells[ev.app_name] || 0) + sec;
    }

    if (i > 0 && (ev.app_name !== telemetry[i - 1].app_name || ev.window_title !== telemetry[i - 1].window_title)) {
      switches++;
    }
  }

  let longestSessionSec = 0;
  let longestSessionApp = '';
  for (const s of sessions) {
    if (s.duration_s > longestSessionSec) {
      longestSessionSec = Math.round(s.duration_s);
      longestSessionApp = s.anchor_app || '';
    }
  }

  let topApp = '';
  let topAppDwell = 0;
  for (const [appName, dwell] of Object.entries(appDwells)) {
    if (dwell > topAppDwell) {
      topAppDwell = dwell;
      topApp = appName;
    }
  }

  const avgDwellBetweenSwitchesSec = switches > 0 ? Math.round(totalSec / switches) : totalSec;

  // Honest evidence-grounded workState calculation (never assume 0 distraction = productive when deep work is 0)
  let workState = 'AWAITING_ACTIVITY';
  if (totalSec > 0) {
    if (deepWorkSec > 0 && deepWorkSec >= distractionSec * 1.5) {
      workState = 'PRODUCTIVE';
    } else if (distractionSec > deepWorkSec) {
      workState = 'UNSETTLED';
    } else if (deepWorkSec > 0) {
      workState = 'BALANCED';
    } else {
      workState = 'ROUTINE';
    }
  }

  const formatMinSec = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return m > 0 ? `${m}m ${sec}s` : `${sec}s`;
  };

  const stat_sub = {
    deep_work: longestSessionSec > 0
      ? `Longest flow: ${formatMinSec(longestSessionSec)} in ${longestSessionApp || 'editor'}`
      : deepWorkSec > 0
      ? `— ${formatMinSec(deepWorkSec)} focused work & research`
      : '0s focused work recorded',
    distraction: distractionSec > 0
      ? `↓ ${formatMinSec(distractionSec)} distraction (${Math.round((distractionSec / (totalSec || 1)) * 100)}% of time)`
      : deepWorkSec > 0
      ? '0s recorded distraction · High focus'
      : totalSec > 0
      ? '0s recorded distraction · Routine activity'
      : '0s recorded distraction',
    context_switches: switches > 0
      ? `Avg ${formatMinSec(avgDwellBetweenSwitchesSec)} between ${switches} switches`
      : '0 window transitions detected',
    work_state: totalSec === 0
      ? 'Awaiting activity collection'
      : deepWorkSec > 0
      ? `Flow ratio: ${Math.round((deepWorkSec / (totalSec || 1)) * 100)}% deep work · Verified`
      : `0% deep work classified · ${formatMinSec(totalSec)} total tracked`,
  };

  const firstEv = telemetry[0];
  const lastEv = telemetry[telemetry.length - 1];
  const peak_focus_window = firstEv && lastEv ? `${firstEv.timestamp || 'Now'} - ${lastEv.timestamp || 'Now'}` : 'No activity yet';

  const computedSummary: DailySynthesis = {
    date: todayStr || new Date().toISOString().split('T')[0],
    total_deep_work_s: deepWorkSec,
    total_distraction_s: distractionSec,
    total_telemetry_s: totalSec,
    fragmentation_score: totalSec > 0 ? Math.min(10, Number(((switches / (totalSec / 60 || 1)) * 2).toFixed(1))) : 0,
    peak_focus_window,
    context_switches: switches,
    distraction_triggers: Array.from(triggers),
    daily_narrative:
      totalSec > 0
        ? `Reconstructed ${formatMinSec(totalSec)} of continuous laptop activity with ${formatMinSec(deepWorkSec)} deep focus and ${switches} application switches.`
        : 'Waiting for activity collection from your Windows agent.',
    unfinished_work: [],
    work_state: workState,
    stat_sub,
    longest_session_s: longestSessionSec,
    longest_session_app: longestSessionApp,
    avg_dwell_per_switch_s: avgDwellBetweenSwitchesSec,
    top_app_today: topApp ? { name: topApp, dwell_s: topAppDwell } : undefined,
    deep_work_ratio: totalSec > 0 ? Math.round((deepWorkSec / totalSec) * 100) : 0,
    distraction_ratio: totalSec > 0 ? Math.round((distractionSec / totalSec) * 100) : 0,
  };

  if (range === 'week' || range === 'past-7-days' || range === '7d') {
    return res.json({
      ...computedSummary,
      range: 'Past 7 Days',
      daily_narrative: `Aggregated 7-day cognitive performance: ${formatMinSec(totalSec)} total activity recorded across development, learning, and utility.`,
    });
  }

  if (range === 'custom') {
    const start = startDate || todayStr;
    const end = endDate || start;
    return res.json({
      ...computedSummary,
      date: `${start} to ${end}`,
      range: `Custom (${start} - ${end})`,
    });
  }

  res.json(computedSummary);
});

router.get(['/api/reentry/:project', '/reentry/:project'], (req, res) => {
  const user = res.locals.user as UserRecord;
  const sessions = getUserSessions(user.id);
  const lastSession = sessions[sessions.length - 1];
  const activeApp = lastSession?.anchor_app || 'Workspace';
  const startTime = lastSession?.start_time || 'recently';
  const primaryTask = lastSession?.primary_task || `Working in ${activeApp}`;

  if (!lastSession) {
    return res.json({
      project: 'Workspace',
      found: false,
      days_ago: 0,
      time_desc: 'No recorded sessions yet',
      headline: 'No recorded sessions yet. Start working on your Windows device to reconstruct your activity.',
      primary_task: 'Idle',
      summary: 'Agent will reconstruct your active workspace once telemetry begins.',
      unresolved_threads: [],
    });
  }

  res.json({
    project: activeApp,
    found: true,
    days_ago: 0,
    time_desc: `today at ${startTime}`,
    headline: `Last active session on ${activeApp} was today (${startTime}). You were working on ${primaryTask}.`,
    primary_task: primaryTask,
    summary: lastSession.summary || `Continuous stream active from ${activeApp}.`,
    unresolved_threads: lastSession.main_events?.map((e) => e.title).slice(0, 3) || ['Active session stream in progress'],
    last_session: lastSession,
  });
});

router.get(['/api/patterns/week', '/patterns/week'], (req, res) => {
  const user = res.locals.user as UserRecord;
  const telemetry = getUserTelemetry(user.id);
  const summary = getUserSummary(user.id);

  // Group by real event dates
  const dailyBreakdown: Record<string, { DEEP_WORK: number; DISTRACTION: number; TOTAL: number }> = {};
  for (const ev of telemetry) {
    const d = ev.date || (ev.recorded_at ? new Date(ev.recorded_at).toISOString().split('T')[0] : 'Today');
    if (!dailyBreakdown[d]) {
      dailyBreakdown[d] = { DEEP_WORK: 0, DISTRACTION: 0, TOTAL: 0 };
    }
    const sec = Math.max(1, Math.round((ev.dwell_ms || 2000) / 1000));
    dailyBreakdown[d].TOTAL += sec;
    if (ev.category === 'Deep Work' || ev.category === 'Learning') {
      dailyBreakdown[d].DEEP_WORK += sec;
    } else if (ev.category === 'Entertainment' || ev.category === 'Distraction') {
      dailyBreakdown[d].DISTRACTION += sec;
    }
  }

  const dates = Object.keys(dailyBreakdown);
  res.json({
    start_date: dates[0] || new Date().toISOString().split('T')[0],
    daily_breakdown: dailyBreakdown,
    common_triggers: summary.distraction_triggers?.map((t) => ({ trigger: t, count: 1 })) || [],
  });
});

router.post(['/api/sessions/:chunkId/correct', '/sessions/:chunkId/correct'], (req, res) => {
  const { chunkId } = req.params;
  const { intent } = req.body;
  const user = res.locals.user as UserRecord;
  const sessions = getUserSessions(user.id);
  const chunk = sessions.find((s) => s.chunk_id === chunkId);
  if (!chunk) {
    return res.status(404).json({ error: 'Session chunk not found' });
  }

  chunk.intent = intent;
  chunk.user_corrected = true;
  saveUserSessions(user.id, sessions);
  res.json({ success: true, chunk });
});


export default router;
