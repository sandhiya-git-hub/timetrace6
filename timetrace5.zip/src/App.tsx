import React, { useState, useEffect } from 'react';
import { SplashScreen } from './components/SplashScreen';
import { GoogleAuthScreen } from './components/GoogleAuthScreen';
import { AppHeader } from './components/AppHeader';
import { DashboardView } from './components/DashboardView';
import { ActivityTimelineView } from './components/ActivityTimelineView';
import { RawActivityView } from './components/RawActivityView';
import { AiAssistantView } from './components/AiAssistantView';
import { DeviceModal } from './components/DeviceModal';
import { PrivacyModal } from './components/PrivacyModal';
import {
  AppScreen,
  ChunkSummary,
  DailySynthesis,
  DeviceState,
  IntentLabel,
  PrimaryNavTab,
  ReentryBriefing,
  TelemetryEvent,
  UserProfile,
} from '@shared/types/chronotrace';
import { apiFetch, apiFetchJson, setStoredSessionToken } from './lib/api';

export default function App() {
  // Navigation & Screen Lifecycle: 3 simple stages (Splash -> Auth -> Permanent Dashboard)
  const [screen, setScreen] = useState<AppScreen>('splash');
  const [activeTab, setActiveTab] = useState<PrimaryNavTab>('dashboard');

  // Core Data
  const [user, setUser] = useState<UserProfile | null>(null);
  const [authStartMode, setAuthStartMode] = useState<'signin' | 'register'>('signin');
  const [device, setDevice] = useState<DeviceState | null>(null);
  const [events, setEvents] = useState<TelemetryEvent[]>([]);
  const [chunks, setChunks] = useState<ChunkSummary[]>([]);
  const [dailySummary, setDailySummary] = useState<DailySynthesis | null>(null);
  const [reentryBriefing, setReentryBriefing] = useState<ReentryBriefing | null>(null);

  // States & Modals
  const [isSynthesizing, setIsSynthesizing] = useState<boolean>(false);
  const [deviceModalOpen, setDeviceModalOpen] = useState<boolean>(false);
  const [privacyModalOpen, setPrivacyModalOpen] = useState<boolean>(false);
  const [initialAssistantPrompt, setInitialAssistantPrompt] = useState<string | undefined>(undefined);
  const [liveFileHandle, setLiveFileHandle] = useState<any | null>(null);

  const safeFetchJson = React.useCallback(async (url: string) => {
    return await apiFetchJson(url);
  }, []);

  const fetchDeviceStatus = React.useCallback(async () => {
    const data = await safeFetchJson('/api/device/status');
    if (data) setDevice(data);
  }, [safeFetchJson]);

  // Check initial authentication and fetch core datasets once on mount
  useEffect(() => {
    checkAuthAndInit();
  }, []);

  // Continuous background file watcher for live telemetry streaming from local chronotrace_live.json
  useEffect(() => {
    if (!liveFileHandle) return;
    let active = true;
    let lastContent = '';

    const syncFile = async () => {
      try {
        const file = await liveFileHandle.getFile();
        const text = await file.text();
        if (text && text !== lastContent && active) {
          lastContent = text;
          const parsed = JSON.parse(text);
          await apiFetch('/api/agent/sync-file', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              sessions: parsed.sessions || [],
              current: parsed.current,
              userToken: user?.deviceToken,
              deviceName: parsed.deviceName || 'Windows Workstation',
              os: parsed.os,
            }),
          });
          fetchDeviceStatus();
          fetchAllActivityData();
        }
      } catch {
        // Non-fatal read attempt
      }
    };

    // Immediate initial sync
    syncFile();
    const interval = setInterval(syncFile, 1500);

    return () => {
      active = false;
      clearInterval(interval);
    };
  }, [liveFileHandle, user, fetchDeviceStatus]);

  // Smooth periodic polling for live telemetry and device connection state
  useEffect(() => {
    if (screen !== 'app') return;

    // Immediate poll
    fetchDeviceStatus();
    fetchAllActivityData();

    const interval = setInterval(() => {
      fetchDeviceStatus();
      fetchAllActivityData();
    }, 2000);

    return () => clearInterval(interval);
  }, [screen, fetchDeviceStatus]);

  const checkAuthAndInit = async () => {
    try {
      const authRes = await safeFetchJson('/api/auth/session');
      if (authRes?.authenticated && authRes.user) {
        if (authRes.token) {
          try {
            localStorage.setItem('chronotrace_session_token', authRes.token);
          } catch {}
        }
        setUser(authRes.user);

        const devRes = await safeFetchJson('/api/device/status');
        if (devRes) setDevice(devRes);

        await fetchAllActivityData();

        // Direct access to Dashboard for authenticated users
        setScreen('app');
      } else {
        setUser(null);
        setDevice(null);
      }
    } catch {
      // Non-fatal init fallback
    }
  };

  const fetchAllActivityData = React.useCallback(async () => {
    try {
      const [eventsRes, sessionsRes, summaryRes, reentryRes] = await Promise.all([
        safeFetchJson('/api/telemetry/raw?limit=100'),
        safeFetchJson('/api/sessions'),
        safeFetchJson('/api/summary/today'),
        safeFetchJson('/api/reentry/TS%20Assignment'),
      ]);

      if (eventsRes?.events && Array.isArray(eventsRes.events)) {
        setEvents(eventsRes.events);
      } else if (Array.isArray(eventsRes)) {
        setEvents(eventsRes);
      }

      if (Array.isArray(sessionsRes)) setChunks(sessionsRes);
      if (summaryRes) setDailySummary(summaryRes);
      if (reentryRes) setReentryBriefing(reentryRes);
    } catch {
      // Retain current datasets if network hiccup occurs
    }
  }, [safeFetchJson]);

  // Auth flow transitions: directly lands on Dashboard!
  const handleAuthSuccess = (authenticatedUser: UserProfile, _isFirstTime: boolean = false) => {
    setUser(authenticatedUser);
    fetchAllActivityData();
    fetchDeviceStatus();
    setScreen('app');
  };

  const handleLogout = async () => {
    try {
      await apiFetch('/api/auth/logout', {
        method: 'POST',
      });
    } catch {}
    try {
      localStorage.removeItem('chronotrace_session_token');
      sessionStorage.removeItem('chronotrace_session_token');
    } catch {}
    setUser(null);
    setLiveFileHandle(null);
    setDevice(null);
    setEvents([]);
    setChunks([]);
    setDailySummary(null);
    setReentryBriefing(null);
    setScreen('splash');
  };

  const handleRefreshSummary = async () => {
    setIsSynthesizing(true);
    try {
      const res = await apiFetch('/api/gemini/synthesize-day', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessions: chunks }),
      });
      if (res.ok) {
        const data = await res.json();
        setDailySummary(data);
      }
    } catch (e) {
      console.error('Error refreshing summary:', e);
    } finally {
      setIsSynthesizing(false);
    }
  };

  const handleCorrectIntent = async (chunkId: string, newIntent: IntentLabel) => {
    try {
      const res = await apiFetch(`/api/sessions/${chunkId}/correct`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ intent: newIntent }),
      });
      if (res.ok) {
        setChunks((prev) =>
          prev.map((c) =>
            c.chunk_id === chunkId
              ? { ...c, intent: newIntent, user_corrected: true }
              : c
          )
        );
      }
    } catch (e) {
      console.error('Error updating intent:', e);
    }
  };

  const handleNavigateToAssistantWithPrompt = (prompt?: string) => {
    setInitialAssistantPrompt(prompt);
    setActiveTab('assistant');
  };

  // -------------------------------------------------------------
  // USER JOURNEY RENDER ROUTING
  // -------------------------------------------------------------

  // Stage 1: Splash Screen
  if (screen === 'splash') {
    return (
      <SplashScreen
        onGetStarted={() => {
          setAuthStartMode('register');
          setScreen('auth');
        }}
        onSignIn={() => {
          setAuthStartMode('signin');
          setScreen('auth');
        }}
      />
    );
  }

  // Stage 2: Authentication (Google sign-in or email/username and password)
  if (screen === 'auth') {
    return (
      <GoogleAuthScreen
        key={authStartMode}
        initialMode={authStartMode}
        onSuccess={handleAuthSuccess}
        onBackToSplash={() => setScreen('splash')}
      />
    );
  }

  // Stage 3-6: Permanent Dashboard and Core Application (Never gated by connection)
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans selection:bg-blue-100">
      {/* Persistent Navigation Header */}
      <AppHeader
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        user={user}
        device={device}
        liveFileActive={Boolean(liveFileHandle)}
        onOpenDeviceModal={() => setDeviceModalOpen(true)}
        onOpenPrivacyModal={() => setPrivacyModalOpen(true)}
        onLogout={handleLogout}
      />

      {/* Main Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6">
        {/* Stage 3: Dashboard (Welcome, activity summary, compact connection status, and recent activity) */}
        {activeTab === 'dashboard' && (
          <DashboardView
            user={user}
            device={device}
            summary={dailySummary}
            chunks={chunks}
            events={events}
            reentry={reentryBriefing}
            onRefreshSummary={handleRefreshSummary}
            isSynthesizing={isSynthesizing}
            onNavigateToTimeline={() => setActiveTab('timeline')}
            onNavigateToAssistant={handleNavigateToAssistantWithPrompt}
            onOpenDeviceModal={() => setDeviceModalOpen(true)}
          />
        )}

        {/* Stage 4: Timeline (Reconstructed sessions) */}
        {activeTab === 'timeline' && (
          <ActivityTimelineView
            chunks={chunks}
            onCorrectIntent={handleCorrectIntent}
            onOpenDeviceModal={() => setDeviceModalOpen(true)}
          />
        )}

        {/* Stage 5: Activity (Raw recorded events) */}
        {activeTab === 'raw' && (
          <RawActivityView
            events={events}
            onOpenDeviceModal={() => setDeviceModalOpen(true)}
          />
        )}

        {/* Stage 6: AI Assistant (Ask questions about available activity and work sessions) */}
        {activeTab === 'assistant' && (
          <AiAssistantView
            initialPrompt={initialAssistantPrompt}
            hasEvents={events.length > 0 || chunks.length > 0}
            onNavigateToTimeline={() => setActiveTab('timeline')}
          />
        )}
      </main>

      {/* Dedicated Device Connection Modal Dialog */}
      {deviceModalOpen && (
        <DeviceModal
          device={device}
          userToken={user?.deviceToken}
          liveFileActive={Boolean(liveFileHandle)}
          onSetLiveFileHandle={(handle) => setLiveFileHandle(handle)}
          onStopLiveStream={() => setLiveFileHandle(null)}
          onTokenRegenerated={(newToken) => {
            setUser((prev) => (prev ? { ...prev, deviceToken: newToken } : null));
          }}
          onClose={() => setDeviceModalOpen(false)}
          onRefresh={async () => {
            const devRes = await safeFetchJson('/api/device/status');
            if (devRes) setDevice(devRes);
            fetchAllActivityData();
          }}
        />
      )}

      {/* Privacy Guarantee Modal */}
      {privacyModalOpen && (
        <PrivacyModal onClose={() => setPrivacyModalOpen(false)} />
      )}
    </div>
  );
}
