# Sign-in, registration and splash fixes

## Why sign-in failed with correct credentials

Each cause below was reproduced against the previous code, with curl and with the UI in Chromium.

1. **A legacy account record without `email` broke every sign-in.** Login searched the accounts
   with `u.email.toLowerCase()`. A record without `email` threw
   `Cannot read properties of undefined`, and Express returned an HTML 500 page for every other
   account in the file. The UI then reported a JSON parse error, not a sign-in result.
2. **The documented split dev setup had no `/api` proxy.** `frontend/vite.config.ts` did not
   forward `/api`, so on :5173 every sign-in request got an empty 404.
3. **A damaged `users.json` was overwritten on the next registration.** `getUsers()` returned `[]`
   when the file could not be parsed. Registration then saved a file containing only the new
   account. Reproduced: the existing account was lost.
4. **`backend/.env` was ignored when the server started from the repo root.** `dotenv` only read
   `.env` from the current directory.
5. **Save failures were silent.** `saveUsers()` logged and returned, so registration could return
   201 without saving the account.
6. **Device setup was never saved.** `complete-device-setup` modified an object from one read of
   the file and then saved a second, unmodified read.
7. **Passwords were trimmed on both client and server.** Passwords are now sent and verified exactly
   as typed. Accounts created before this change still sign in with their trimmed password.

## Backend

- `shared/validation/auth.ts` is the single source of the registration rules. The browser and the
  API both use it. Rules: name (2–60 characters, letters with spaces, apostrophes, hyphens and
  periods); username (3–20 characters, letters, numbers and underscores, stored lowercase); email
  (valid format, stored lowercase, unique); password (8+ characters, uppercase, lowercase, number,
  special character, at most 72 bytes); confirm password (must match).
- `POST /api/auth/register` returns per-field errors (`fieldErrors`) and 409 for duplicate username
  or email, regardless of case.
- `POST /api/auth/login` accepts a username or email, in any case. Unknown accounts and wrong
  passwords return the same 401, and an unknown account still runs a bcrypt comparison.
- The session token is no longer returned in the JSON body. It is only in the httpOnly cookie.
  `COOKIE_SECURE=true` adds the `Secure` flag for HTTPS deployments.
- `GET /api/auth/config` is public and returns the Google client ID (which is not secret).
- `POST /api/auth/google` verifies the Google ID token with `google-auth-library`, checking signature,
  expiry, issuer, audience and `email_verified`. Without `GOOGLE_CLIENT_ID` it returns 503 with a
  setup message. It does not attach to an existing password account with the same email; it returns
  409 instead, so a password account is never taken over through Google.
- `userStore.ts` fails closed: unreadable or malformed store files raise `UserStoreError`. Writes
  are atomic (temp file, then rename) and save errors propagate.
- Missing `email`, `username` or `name` in legacy records is normalized on read.
- `app.ts` returns JSON for every API error, including malformed request bodies.
- `env.ts` loads `backend/.env` and then the root `.env`.

## Frontend

- `SplashScreen.tsx` is rebuilt: headline "Your workday, reconstructed.", Get Started (opens
  Create Account) and Sign In (opens the sign-in tab), and a three-step "How it works" timeline with
  subtle motion that respects reduced-motion settings. The fake progress bar, the fabricated
  percentages and the activity legend are removed.
- `GoogleAuthScreen.tsx` has inline per-field validation with a live password checklist, and blocks
  invalid submissions without sending a request. Google sign-in loads Google Identity Services and
  renders Google's button when a client ID is configured. Otherwise it shows a setup message.
- `lib/authApi.ts` turns non-JSON responses and network failures into readable messages.
- Logout clears in-memory account data and stops the live file sync, so the next account on the
  same browser never sees the previous account's data.
- `vite.config.ts` runs the dev server on :5173 and proxies `/api` to the backend port.
- The backend's `package.json` gains `google-auth-library` and a `test` script.

## Tests and verification

- `cd backend && npm test`: 33 tests (validation rules, registration, login by username and email,
  session persistence, logout, protected routes, and regressions for the three data-path bugs above).
- UI end-to-end run in Chromium (21 checks): splash content, navigation, inline validation with no
  request sent, registration, reload persistence, logout, wrong and right sign-ins, mobile layout.
- Typecheck for root, backend and frontend; `npm run build` produces `frontend/dist`, and the
  production server serves it with the API on the same origin.

## Not done, and needs your decision or configuration

- **Google needs a real client ID.** Set `GOOGLE_CLIENT_ID` in `backend/.env` and add the local
  origins as Authorized JavaScript origins. The live Google flow was not exercised here because the
  test environment cannot reach Google's servers. Verification needs `www.googleapis.com` reachable.
- **Email ownership is not verified for password accounts.** Anyone can register an address they do
  not own. Email verification is the next step before email-based linking is considered safe.
- **No rate limiting on sign-in.** Add it before public deployment.
- **Session tokens are stored in plain text** in `auth_sessions.json`. Storing a hash would be better.
- **Existing `users.json` files.** Run a check for records without a bcrypt hash:
  `grep -c '"passwordHash": "\$2' backend/data/users.json` should equal the number of accounts. Accounts
  without a valid hash cannot sign in with a password and are logged as warnings on the server.

# Phase 1 changes: account isolation and auth hardening

Implements the critical items from docs/ARCHITECTURE.md section 8 (issues 1-4).

## Backend
- Removed the `getDefaultUser()` fallback everywhere. A new guard (`requireSessionUser`,
  mounted in `app.ts`) returns 401 for every data route without a valid session, including
  the non-/api aliases (/sessions, /summary, /reentry, /patterns, /download, agent.py ...).
- Removed seeded accounts (`sandhiya`/`password123`, `admin`/`adminpassword`). A fresh install starts with no users.
- Agent download and PowerShell endpoints require a session and return only the signed-in
  owner's device token. The `?token=` query parameter is no longer accepted.
- Agent ingestion (`/api/ingest-event`, `/api/sync-sessions`) accepts only the exact device
  token. Usernames and user IDs are no longer accepted as credentials, and there is no default user.
- Device tokens and session tokens are generated with `crypto.randomBytes`.
- `/api/auth/google` verifies the Google ID token with Google's tokeninfo endpoint and checks
  `aud` against `GOOGLE_CLIENT_ID`. Client-supplied profiles are no longer trusted.
  Returns 503 when `GOOGLE_CLIENT_ID` is not set.

## Frontend
- Removed the hard-coded Google profile (a fixed personal email and name).
- Google button reports "not configured" instead of faking a sign-in.
- Removed the personal email fallback in the header and the sandhiya placeholder.

## Not yet done (later phases)
- Browser bridge double-counting (issue 5), locked-PC idle handling (issue 6).
- Pairing-code device setup (issue 3 full fix) and real Google button (Google Identity Services).
- SQLite/PostgreSQL storage, event IDs and deduplication.
- Existing `backend/data/users.json` from before this change still contains the seeded accounts.
  Delete that file (or remove those entries) on machines where it exists.

## Verification
`backend/` typechecks, `frontend/` typechecks and builds, and 26 live-server checks pass,
covering anonymous access, cross-account isolation, token handling, ingestion authentication, and logout.
