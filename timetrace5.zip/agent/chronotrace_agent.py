#!/usr/bin/env python3
"""
ChronoTrace Exact-Duration & Topic-Aware Laptop Telemetry Agent
- Zero external pip packages required (100% Python Standard Library)
- Tracks exact seconds spent in every foreground window before switching
- Intelligently classifies YouTube & Social Media topics into Productive (Learning) vs Non-Productive (Entertainment)
- Automatically synchronizes live foreground window activity to the web dashboard for passive activity reconstruction
- Authenticated HTTPS event ingestion directly to the ChronoTrace server
- Bounded local queue with resilient retries, queue flushing, and deduplication
- Saves live session history to ~/chronotrace_live.json & http://127.0.0.1:9876/live
"""
import os
import re
import time
import json
import platform
import subprocess
import threading
import collections
import urllib.error
import urllib.request
import sys
import ssl
import hashlib
import base64
import struct
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

try:
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(line_buffering=True)
except Exception:
    pass

PORT = 9876

# Default Server Host and User Token (dynamically injected on download or provided via argv)
DEFAULT_SERVER = "http://localhost:3000"
DEFAULT_USER_TOKEN = ""

# Parse CLI arguments for server URL and user token
SERVER_BASE = DEFAULT_SERVER
USER_TOKEN = DEFAULT_USER_TOKEN
TEST_MODE = os.environ.get("CHRONOTRACE_TEST_MODE", "").lower() in ("1", "true", "yes")

args = sys.argv[1:]
idx = 0
while idx < len(args):
    arg = args[idx].strip()
    if arg in ("--token", "-t") and idx + 1 < len(args):
        USER_TOKEN = args[idx + 1].strip().strip("\"'")
        idx += 2
        continue
    elif arg.startswith("--token="):
        USER_TOKEN = arg.split("=", 1)[1].strip().strip("\"'")
        idx += 1
        continue
    elif arg in ("--server", "-s") and idx + 1 < len(args):
        raw_val = args[idx + 1].strip().strip("\"'")
        if not raw_val.startswith("http://") and not raw_val.startswith("https://"):
            SERVER_BASE = "https://" + raw_val
        else:
            SERVER_BASE = raw_val
        idx += 2
        continue
    elif arg.startswith("--server="):
        raw_val = arg.split("=", 1)[1].strip().strip("\"'")
        if not raw_val.startswith("http://") and not raw_val.startswith("https://"):
            SERVER_BASE = "https://" + raw_val
        else:
            SERVER_BASE = raw_val
        idx += 1
        continue
    elif arg in ("--test-events", "--test", "-test"):
        TEST_MODE = True
        idx += 1
        continue
    elif not arg.startswith("-"):
        raw_val = arg.rstrip("/").strip("\"'")
        if not raw_val.startswith("http://") and not raw_val.startswith("https://"):
            SERVER_BASE = "https://" + raw_val
        else:
            SERVER_BASE = raw_val
    idx += 1

USER_TOKEN = USER_TOKEN.strip("\"' ")
SERVER_BASE = SERVER_BASE.strip("\"' ").rstrip("/")

REMOTE_ENDPOINT = f"{SERVER_BASE}/api/ingest-event"
REMOTE_SYNC = f"{SERVER_BASE}/api/sync-sessions"
LIVE_JSON_PATH = os.path.join(os.path.expanduser("~"), "chronotrace_live.json")

# Connection state and bounded local queuing for network resiliency
MAX_QUEUE_SIZE = 250
_event_queue = collections.deque(maxlen=MAX_QUEUE_SIZE)
_queue_lock = threading.Lock()
_link_state = {"state": None, "detail": ""}
_last_successful_push = 0.0

def _report_link(state, detail=""):
    """Print only on state transitions so terminal output stays concise and informative."""
    old_state = _link_state["state"]
    if old_state != state:
        _link_state["state"] = state
        _link_state["detail"] = detail
        if state == "CONNECTED":
            print(f"[CONNECTED] Linked to ChronoTrace website ({SERVER_BASE})")
        elif state == "RECONNECTING":
            print(f"[RECONNECTING] Connection interrupted. Queued events locally. {detail}")
        elif state == "PAUSED":
            print(f"[PAUSED] Activity collection is paused on the website.")
        elif state == "ERROR":
            print(f"[ERROR] {detail}")
        elif state == "NOT_CONNECTED":
            print(f"[NOT CONNECTED] {detail}")

def _get_ssl_context():
    try:
        return ssl.create_default_context()
    except Exception:
        try:
            return ssl._create_unverified_context()
        except Exception:
            return None

def _prepare_event_payload(payload):
    now_dt = datetime.now().astimezone()
    tz_offset_min = int(now_dt.utcoffset().total_seconds() // 60) if now_dt.utcoffset() else 0
    tz_name = now_dt.tzname() or (time.tzname[time.daylight] if (time.daylight and len(time.tzname) > 1) else time.tzname[0])

    if "id" not in payload:
        payload["id"] = f"evt_{int(time.time() * 1000)}_{os.urandom(3).hex()}"
    if "localTime" not in payload:
        payload["localTime"] = now_dt.strftime("%I:%M:%S %p")
    if "localDate" not in payload:
        payload["localDate"] = now_dt.strftime("%Y-%m-%d")
    if "localTimestamp" not in payload:
        payload["localTimestamp"] = now_dt.isoformat()
    if "utcTimestamp" not in payload:
        payload["utcTimestamp"] = datetime.now(timezone.utc).isoformat()
    if "timezoneOffsetMinutes" not in payload:
        payload["timezoneOffsetMinutes"] = tz_offset_min
    if "timezoneName" not in payload:
        payload["timezoneName"] = tz_name
    if USER_TOKEN and "userToken" not in payload:
        payload["userToken"] = USER_TOKEN
    if "deviceName" not in payload:
        payload["deviceName"] = platform.node() or "Windows Workstation"
    if "os" not in payload:
        payload["os"] = f"{platform.system()} {platform.release()}"
    if "agentVersion" not in payload:
        payload["agentVersion"] = "1.3.0"
    return payload

def enqueue_event(payload):
    """Add event to bounded queue for background delivery with retry support."""
    prepared = _prepare_event_payload(dict(payload))
    with _queue_lock:
        _event_queue.append(prepared)

class StrictNoRedirectHandler(urllib.request.HTTPRedirectHandler):
    """Explicitly intercept HTTP redirects to prevent silently following preview proxies to HTML pages."""
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise urllib.error.HTTPError(
            req.full_url,
            code,
            f"HTTP {code} redirect to {newurl} intercepted (auth bridge or preview proxy)",
            headers,
            fp
        )

def _send_http_request(payload_obj):
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "ChronoTraceAgent/1.3.0"
    }
    if USER_TOKEN:
        headers["Authorization"] = f"Bearer {USER_TOKEN}"
        headers["X-Device-Token"] = USER_TOKEN
        headers["X-User-Token"] = USER_TOKEN

    data = json.dumps(payload_obj).encode("utf-8")
    req = urllib.request.Request(
        REMOTE_ENDPOINT,
        data=data,
        headers=headers,
        method="POST"
    )

    ctx = _get_ssl_context()
    handlers = [StrictNoRedirectHandler()]
    if ctx:
        handlers.append(urllib.request.HTTPSHandler(context=ctx))
    opener = urllib.request.build_opener(*handlers)

    try:
        resp = opener.open(req, timeout=8)
    except urllib.error.URLError as u_err:
        err_msg = str(u_err)
        if "CERTIFICATE_VERIFY_FAILED" in err_msg or "certificate" in err_msg.lower() or "ssl" in err_msg.lower():
            try:
                unv = ssl._create_unverified_context()
                unv_handlers = [StrictNoRedirectHandler(), urllib.request.HTTPSHandler(context=unv)]
                unv_opener = urllib.request.build_opener(*unv_handlers)
                resp = unv_opener.open(req, timeout=8)
            except Exception:
                raise u_err
        else:
            raise u_err

    with resp:
        content_type = resp.headers.get("Content-Type", "")
        if "application/json" not in content_type and "text/plain" not in content_type:
            peek = resp.read(200).decode("utf-8", errors="replace").strip().replace("\n", " ")
            raise urllib.error.URLError(f"Non-JSON response from server (status {resp.status}, Content-Type: {content_type}): {peek[:80]}")
        return resp.status in (200, 201)

def event_dispatcher_loop():
    """Background thread that dispatches queued telemetry events and periodic heartbeats."""
    global _last_successful_push
    backoff = 1.0

    while True:
        items_to_send = []
        with _queue_lock:
            if len(_event_queue) > 0:
                # Grab up to 10 events to send as a batch
                count = min(10, len(_event_queue))
                items_to_send = [dict(_event_queue[i]) for i in range(count)]

        now = time.time()
        # If queue is empty, send a periodic heartbeat every 5 seconds to keep connection alive
        if not items_to_send:
            if now - _last_successful_push >= 5.0:
                heartbeat_payload = _prepare_event_payload({
                    "heartbeat": True,
                    "sourceType": "heartbeat",
                    "current": {
                        "appName": current_state.get("appName"),
                        "windowTitle": current_state.get("windowTitle"),
                        "category": current_state.get("category"),
                        "elapsedSeconds": current_state.get("elapsedSeconds", 0),
                        "startTime": current_state.get("startTimeStr"),
                    }
                })
                try:
                    if _send_http_request(heartbeat_payload):
                        _last_successful_push = now
                        _report_link("CONNECTED")
                        backoff = 1.0
                except urllib.error.HTTPError as e:
                    if e.code == 409:
                        _report_link("PAUSED")
                    elif e.code in (401, 403):
                        _report_link("ERROR", f"HTTP {e.code}: Device token invalid or revoked.")
                    else:
                        _report_link("RECONNECTING", f"HTTP {e.code} {e.reason}")
                except Exception as e:
                    _report_link("RECONNECTING", str(e))
            time.sleep(1.0)
            continue

        # Send items (batch or single)
        try:
            if len(items_to_send) == 1:
                success = _send_http_request(items_to_send[0])
            else:
                batch_payload = _prepare_event_payload({
                    "events": items_to_send,
                    "batchCount": len(items_to_send)
                })
                success = _send_http_request(batch_payload)

            if success:
                # Successfully delivered! Remove delivered items from the front of the queue
                with _queue_lock:
                    for _ in range(len(items_to_send)):
                        if _event_queue:
                            _event_queue.popleft()
                _last_successful_push = time.time()
                _report_link("CONNECTED")
                backoff = 1.0
                time.sleep(0.1)
            else:
                _report_link("RECONNECTING", "Non-200 status received.")
                time.sleep(backoff)
                backoff = min(8.0, backoff * 1.5)

        except urllib.error.HTTPError as e:
            if e.code == 409:
                _report_link("PAUSED")
                time.sleep(3.0)
            elif e.code in (401, 403):
                _report_link("ERROR", f"HTTP {e.code}: Device token invalid or revoked on dashboard.")
                time.sleep(5.0)
            else:
                _report_link("RECONNECTING", f"HTTP {e.code} {e.reason}")
                time.sleep(backoff)
                backoff = min(8.0, backoff * 1.5)
        except Exception as e:
            _report_link("RECONNECTING", f"Retrying ({len(_event_queue)} queued): {e}")
            time.sleep(backoff)
            backoff = min(8.0, backoff * 1.5)

FRIENDLY_MAP = {
    "code": "VS Code",
    "chrome": "Google Chrome",
    "msedge": "Microsoft Edge",
    "brave": "Brave Browser",
    "firefox": "Firefox",
    "whatsapp": "WhatsApp",
    "calculatorapp": "Calculator",
    "calc": "Calculator",
    "windowsterminal": "PowerShell",
    "powershell": "PowerShell",
    "cmd": "Command Prompt",
    "explorer": "File Explorer",
    "spotify": "Spotify",
    "slack": "Slack",
    "discord": "Discord",
    "notion": "Notion"
}

PRODUCTIVE_KW = [
    "tutorial", "course", "lecture", "lesson", "algorithm", "graph", "dijkstra", "bfs", "dfs",
    "dynamic programming", "tree", "array", "data structure", "leetcode", "coding", "programming",
    "software", "developer", "engineering", "python", "javascript", "typescript", "react", "node",
    "java", "c++", "rust", "golang", "sql", "database", "docker", "kubernetes", "aws", "cloud",
    "devops", "linux", "git", "github", "system design", "architecture", "api", "frontend", "backend",
    "machine learning", "deep learning", "ai", "artificial intelligence", "llm", "neural", "gpt",
    "gemini", "rag", "agent", "pytorch", "tensorflow", "data science", "analytics", "statistics",
    "math", "calculus", "linear algebra", "physics", "chemistry", "biology", "science", "robotics",
    "cybersecurity", "networking", "operating system", "compiler", "blockchain", "ui", "ux", "figma",
    "design", "startup", "business", "finance", "economics", "investing", "marketing", "seo",
    "productivity", "study", "learn", "learning", "how to", "explained", "guide", "walkthrough",
    "crash course", "masterclass", "bootcamp", "workshop", "seminar", "paper", "research", "arxiv",
    "interview", "resume", "career", "roadmap", "prep", "exam", "gate", "jee", "neet", "upsc",
    "documentary", "history", "philosophy", "psychology", "neuroscience", "medicine", "law",
    "book summary", "audiobook", "podcast", "ted", "mit", "stanford", "harvard", "cs50",
    "freecodecamp", "fireship", "3blue1brown", "neetcode", "striver", "coursera", "udemy",
    "how ", "why ", "what is", "building", "creating", "implementing", "solving", "debugging",
    "understanding", "intro to", "basics of", "advanced", "deep dive", "analysis", "breakdown"
]

NON_PRODUCTIVE_KW = [
    "prank", "vlog", "funny", "comedy", "meme", "roast", "reaction", "unboxing", "gossip", "drama",
    "trailer", "teaser", "movie", "episode", "netflix", "anime", "gaming", "gameplay", "valorant",
    "minecraft", "fortnite", "gta", "roblox", "pubg", "bgmi", "cod", "fifa", "elden ring", "twitch",
    "esports", "speedrun", "music video", "official video", "lyrics", "karaoke", "song", "remix",
    "playlist", "bollywood", "kpop", "dance", "tiktok", "reels", "shorts feed", "asmr", "mukbang",
    "food challenge", "makeup", "grwm", "fashion", "sports highlights", "cricket", "ipl", "football"
]

sessions = []
current_state = {
    "appName": "Waiting...",
    "windowTitle": "Initializing...",
    "elapsedSeconds": 0,
    "timestamp": time.time()
}

def parse_window_exact(raw_app, raw_title):
    clean_title = (raw_title or raw_app or "Active Window").strip()
    app_name = (raw_app or "Application").strip()
    segments = [s.strip() for s in clean_title.replace("—", " - ").split(" - ") if s.strip()]
    last_seg = segments[-1].lower() if segments else ""
    t_low = clean_title.lower()
    a_low = app_name.lower()

    if "visual studio code" in last_seg or a_low == "code":
        app_name = "VS Code"
    elif "google chrome" in last_seg or a_low == "chrome":
        app_name = "Google Chrome"
    elif "microsoft edge" in last_seg or a_low == "msedge":
        app_name = "Microsoft Edge"
    elif "whatsapp" in t_low or "whatsapp" in a_low:
        app_name = "WhatsApp"
    elif "calculator" in t_low or "calc" in a_low:
        app_name = "Calculator"
    elif "powershell" in t_low or a_low in ["powershell", "windowsterminal"]:
        app_name = "PowerShell"

    content_segs = list(segments)
    if len(content_segs) > 1 and any(b in last_seg for b in ["google chrome", "visual studio code", "microsoft edge", "brave", "firefox"]):
        content_segs.pop()

    primary = content_segs[0] if content_segs else clean_title
    secondary = " — ".join(content_segs[1:]) if len(content_segs) > 1 else app_name

    is_yt_or_social = any(s in t_low for s in ["youtube", "reddit", "linkedin", "twitter", "x.com", "medium", "instagram"])

    if app_name == "VS Code":
        cat = "Deep Work"
        task = f"Editing {content_segs[0]} ({content_segs[1]})" if len(content_segs) >= 2 else f"VS Code: {primary}"
        topics = [content_segs[0]]
    elif is_yt_or_social:
        topic_clean = re.sub(r"^\(\d+\)\s*", "", primary).strip()
        platform_name = "YouTube" if "youtube" in t_low else ("Reddit" if "reddit" in t_low else "Social Media")
        has_prod = any(k in t_low for k in PRODUCTIVE_KW)
        has_non_prod = any(k in t_low for k in NON_PRODUCTIVE_KW)
        if has_prod and not has_non_prod:
            cat = "Learning"
            task = f"{platform_name} (Productive Learning): {topic_clean}"
            topics = [topic_clean]
        else:
            cat = "Entertainment"
            task = f"{platform_name} (Leisure / Non-Productive): {topic_clean}"
            topics = []
    elif app_name == "WhatsApp" or any(k in t_low for k in ["slack", "discord", "telegram", "teams"]):
        cat = "Communication"
        task = f"{app_name}: {primary}"
        topics = []
    elif app_name == "Calculator":
        cat = "Utility"
        task = f"Calculator: {clean_title}"
        topics = []
    elif any(k in t_low for k in PRODUCTIVE_KW):
        cat = "Learning"
        task = f"{primary} ({secondary})"
        topics = [primary]
    elif any(k in t_low for k in NON_PRODUCTIVE_KW):
        cat = "Entertainment"
        task = f"{primary} ({secondary})"
        topics = []
    else:
        is_work = any(k in t_low for k in ["ai studio", "chronotrace", "localhost", "127.0.0.1", "docs.google", "sheets.google", "figma", "notion"])
        cat = "Deep Work" if is_work else "Utility"
        task = f"{primary} ({secondary})" if len(content_segs) > 1 else f"{app_name}: {primary}"
        topics = [primary] if is_work else []

    return app_name, secondary, task, cat, topics

def get_windows_active_window():
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32
        psapi = ctypes.windll.psapi

        hwnd = user32.GetForegroundWindow()
        if not hwnd:
            return None, None
        length = user32.GetWindowTextLengthW(hwnd)
        buf = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, buf, length + 1)
        title = buf.value.strip()
        if not title:
            return None, None

        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        
        # Try PROCESS_QUERY_LIMITED_INFORMATION (0x1000) first to read elevated/UWP process titles
        h_process = kernel32.OpenProcess(0x1000, False, pid.value)
        if not h_process:
            h_process = kernel32.OpenProcess(0x0400 | 0x0010, False, pid.value)

        app_name = ""
        if h_process:
            exe_buf = ctypes.create_unicode_buffer(512)
            size = wintypes.DWORD(512)
            if hasattr(kernel32, 'QueryFullProcessImageNameW') and kernel32.QueryFullProcessImageNameW(h_process, 0, exe_buf, ctypes.byref(size)):
                full_path = exe_buf.value
                app_name = os.path.basename(full_path).replace(".exe", "").replace(".EXE", "")
            elif psapi.GetModuleBaseNameW(h_process, None, exe_buf, 512) > 0:
                app_name = exe_buf.value.replace(".exe", "").replace(".EXE", "")
            kernel32.CloseHandle(h_process)

        if not app_name:
            parts = [p.strip() for p in title.split(" - ") if p.strip()]
            app_name = parts[-1] if len(parts) >= 2 else "Windows App"

        norm = FRIENDLY_MAP.get(app_name.lower(), app_name)
        return norm, title
    except Exception:
        return None, None

def get_macos_active_window():
    try:
        app_cmd = 'tell application "System Events" to get name of first application process whose frontmost is true'
        title_cmd = 'tell application "System Events" to tell (first application process whose frontmost is true) to get name of front window'
        app_name = subprocess.check_output(["osascript", "-e", app_cmd], stderr=subprocess.DEVNULL).decode("utf-8", errors="ignore").strip()
        try:
            win_title = subprocess.check_output(["osascript", "-e", title_cmd], stderr=subprocess.DEVNULL).decode("utf-8", errors="ignore").strip()
        except Exception:
            win_title = app_name
        return app_name or "macOS App", win_title or app_name
    except Exception:
        return None, None

def get_linux_active_window():
    try:
        win_id = subprocess.check_output(["xdotool", "getactivewindow"], stderr=subprocess.DEVNULL).decode().strip()
        win_title = subprocess.check_output(["xdotool", "getwindowname", win_id], stderr=subprocess.DEVNULL).decode().strip()
        app_name = win_title.split(" - ")[-1] if " - " in win_title else "Linux App"
        return app_name, win_title
    except Exception:
        return None, None

# Test simulation sequence for automated testing
_test_seq = [
    ("VS Code", "server.ts - chronotrace - Visual Studio Code"),
    ("Google Chrome", "React 19 Hooks and Architecture - Documentation - Google Chrome"),
    ("Command Prompt", "PowerShell 7 - npm test"),
    ("VS Code", "agent.routes.ts - chronotrace - Visual Studio Code"),
]
_test_step = 0

def get_simulated_active_window():
    global _test_step
    item = _test_seq[_test_step % len(_test_seq)]
    _test_step += 1
    return item[0], item[1]

def save_live_json():
    try:
        now_iso = datetime.now(timezone.utc).isoformat()
        payload_data = {
            "status": "ok",
            "heartbeat": True,
            "lastHeartbeatAt": now_iso,
            "connected": True,
            "deviceName": platform.node() or "Windows Workstation",
            "os": f"{platform.system()} {platform.release()}",
            "userToken": USER_TOKEN,
            "current": current_state,
            "sessions": sessions
        }
        with open(LIVE_JSON_PATH, "w", encoding="utf-8") as f:
            json.dump(payload_data, f, indent=2)
        with open("chronotrace_live.json", "w", encoding="utf-8") as f:
            json.dump(payload_data, f, indent=2)
    except Exception:
        pass

def format_sec(s):
    s = int(round(s))
    if s < 60:
        return f"{s}s"
    return f"{s // 60}m {s % 60}s"

def poll_os_loop():
    sys_name = platform.system()
    last_tick = time.time()
    tick_count = 0

    while True:
        time.sleep(1)
        now = time.time()
        delta = max(1, round(now - last_tick))
        last_tick = now
        tick_count += 1

        try:
            if TEST_MODE:
                # In test mode, rotate window every 4 seconds
                if tick_count % 4 == 0 or tick_count == 1:
                    raw_app, raw_title = get_simulated_active_window()
                else:
                    raw_app = current_state.get("appName")
                    raw_title = current_state.get("windowTitle")
            elif sys_name == "Windows":
                raw_app, raw_title = get_windows_active_window()
            elif sys_name == "Darwin":
                raw_app, raw_title = get_macos_active_window()
            else:
                raw_app, raw_title = get_linux_active_window()

            if not raw_app or not raw_title:
                # No readable foreground window (e.g. lock screen/minimized)
                continue

            app_name, site_mod, task, cat, topics = parse_window_exact(raw_app, raw_title)
            now_str = datetime.now().strftime("%H:%M:%S")
            sig = f"{app_name}:::{raw_title}"

            if sessions and f"{sessions[-1]['appName']}:::{sessions[-1]['windowTitle']}" == sig:
                sessions[-1]["durationSeconds"] += delta
                sessions[-1]["durationMinutes"] = round(sessions[-1]["durationSeconds"] / 60.0, 2)
                sessions[-1]["endTime"] = now_str
                current_state["elapsedSeconds"] = sessions[-1]["durationSeconds"]
            else:
                # Previous window session has completed; enqueue it once with stable ID and exact duration
                if sessions:
                    prev = sessions[-1]
                    print(f"[{prev['endTime']} | {format_sec(prev['durationSeconds'])}] [{prev['category']}] {prev['appName']}  -->  {prev['windowTitle']}")
                    completed_event = {
                        "id": prev["id"],
                        "appName": prev["appName"],
                        "windowTitle": prev["windowTitle"],
                        "deltaSeconds": prev["durationSeconds"],
                        "durationSeconds": prev["durationSeconds"],
                        "overrideCategory": prev["category"],
                        "overrideTask": prev["specificTask"],
                        "overrideTopics": prev.get("extractedTopics", []),
                        "sourceType": "os-hook",
                        "localTime": prev["startTime"],
                        "endTime": prev["endTime"],
                        "localDate": prev.get("localDate", datetime.now().strftime("%Y-%m-%d")),
                        "userToken": USER_TOKEN,
                        "deviceName": platform.node() or "Windows PC",
                        "os": f"{platform.system()} {platform.release()}",
                    }
                    if TEST_MODE:
                        completed_event["isTest"] = True
                    enqueue_event(completed_event)
                    broadcast_ws(completed_event)

                # Generate deterministic, stable unique ID for the new window session
                stable_id = f"evt_{int(now * 1000)}_{hashlib.sha256(f'{USER_TOKEN}_{app_name}_{raw_title}_{int(now)}'.encode('utf-8')).hexdigest()[:10]}"
                today_str = datetime.now().strftime("%Y-%m-%d")

                new_sess = {
                    "id": stable_id,
                    "startTime": now_str,
                    "endTime": now_str,
                    "startTimeEpoch": now,
                    "localDate": today_str,
                    "durationSeconds": delta,
                    "durationMinutes": round(delta / 60.0, 2),
                    "appName": app_name,
                    "processName": raw_app.lower().replace(" ", ""),
                    "siteOrModule": site_mod,
                    "windowTitle": raw_title,
                    "specificTask": task,
                    "category": cat,
                    "extractedTopics": topics,
                    "cognitiveDepth": "High" if cat in ["Deep Work", "Learning"] else "Low",
                    "contextSwitchesInBlock": 1,
                    "sourceType": "os-hook",
                    "inferredIntent": f"Active window: {task}"
                }
                sessions.append(new_sess)
                current_state["elapsedSeconds"] = delta
                print(f"[ACTIVE NOW | {cat}] {app_name}  -->  {raw_title}")

            current_state["appName"] = app_name
            current_state["windowTitle"] = raw_title
            current_state["specificTask"] = task
            current_state["category"] = cat
            current_state["timestamp"] = now
            current_state["startTimeStr"] = sessions[-1]["startTime"] if sessions else now_str

            if tick_count % 3 == 0:
                save_live_json()
        except Exception:
            pass

ws_clients = set()
ws_lock = threading.Lock()

def ws_handshake(key):
    magic = b"258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
    sha1 = hashlib.sha1(key.encode("utf-8") + magic).digest()
    return base64.b64encode(sha1).decode("utf-8")

def make_ws_frame(message_bytes):
    length = len(message_bytes)
    if length <= 125:
        header = bytes([0x81, length])
    elif length <= 65535:
        header = struct.pack("!BBH", 0x81, 126, length)
    else:
        header = struct.pack("!BBQ", 0x81, 127, length)
    return header + message_bytes

def broadcast_ws(payload):
    try:
        msg_bytes = json.dumps(payload).encode("utf-8")
        frame = make_ws_frame(msg_bytes)
        with ws_lock:
            dead = []
            for client in list(ws_clients):
                try:
                    client.sendall(frame)
                except Exception:
                    dead.append(client)
            for d in dead:
                ws_clients.discard(d)
    except Exception:
        pass

class BridgeHandler(BaseHTTPRequestHandler):
    def _send_cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS, HEAD")
        self.send_header("Access-Control-Allow-Headers", "*")
        self.send_header("Access-Control-Allow-Private-Network", "true")

    def do_OPTIONS(self):
        self.send_response(204)
        self._send_cors()
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        upgrade_hdr = self.headers.get("Upgrade", "")
        if upgrade_hdr.lower() == "websocket":
            key = self.headers.get("Sec-WebSocket-Key", "")
            if key:
                accept_val = ws_handshake(key.strip())
                self.send_response(101, "Switching Protocols")
                self.send_header("Upgrade", "websocket")
                self.send_header("Connection", "Upgrade")
                self.send_header("Sec-WebSocket-Accept", accept_val)
                self.end_headers()

                sock = self.request
                with ws_lock:
                    ws_clients.add(sock)

                init_msg = json.dumps({
                    "appName": current_state["appName"],
                    "windowTitle": current_state["windowTitle"],
                    "overrideTask": current_state.get("specificTask", current_state["windowTitle"]),
                    "overrideCategory": current_state.get("category", "Utility"),
                    "deltaSeconds": 1,
                    "userToken": USER_TOKEN,
                    "deviceName": platform.node() or "Windows PC",
                    "os": f"{platform.system()} {platform.release()}",
                    "heartbeat": True
                }).encode("utf-8")
                try:
                    sock.sendall(make_ws_frame(init_msg))
                except Exception:
                    pass

                try:
                    while True:
                        head = sock.recv(2)
                        if not head:
                            break
                        opcode = head[0] & 0x0f
                        if opcode == 0x8:
                            break
                        length = head[1] & 0x7f
                        if length == 126:
                            ext = sock.recv(2)
                            length = struct.unpack("!H", ext)[0]
                        elif length == 127:
                            ext = sock.recv(8)
                            length = struct.unpack("!Q", ext)[0]
                        mask = sock.recv(4) if (head[1] & 0x80) else None
                        if length > 0:
                            sock.recv(length)
                except Exception:
                    pass
                finally:
                    with ws_lock:
                        ws_clients.discard(sock)
                return

        # Regular HTTP response (JSON)
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self._send_cors()
        self.end_headers()
        payload = json.dumps({
            "status": "ok",
            "heartbeat": True,
            "userToken": USER_TOKEN,
            "deviceName": platform.node() or "Windows PC",
            "os": f"{platform.system()} {platform.release()}",
            "appName": current_state["appName"],
            "windowTitle": current_state["windowTitle"],
            "specificTask": current_state.get("specificTask", current_state["windowTitle"]),
            "category": current_state.get("category", "Utility"),
            "elapsedSeconds": current_state["elapsedSeconds"],
            "timestamp": current_state["timestamp"],
            "sessions": sessions
        }).encode("utf-8")
        self.wfile.write(payload)

    def log_message(self, format, *args):
        return

if __name__ == "__main__":
    print("================================================================")
    print("  ChronoTrace Windows Activity Reconstruction Telemetry Agent")
    print(f"  Target Website: {SERVER_BASE}")
    print(f"  Ingest URL:     {REMOTE_ENDPOINT}")
    if USER_TOKEN:
        masked_token = USER_TOKEN[:6] + "..." + USER_TOKEN[-4:] if len(USER_TOKEN) > 10 else USER_TOKEN
        print(f"  Device Token:   {masked_token} (Paired to User Account)")
    else:
        print("  Device Token:   None (Warning: Pairing Token Required)")
    if TEST_MODE:
        print("  Mode:           Simulated Test Windows Active")
    else:
        print("  Mode:           Passive Foreground Window Hook Active")
    print("  Privacy:        Only active window title is read. No keys/screens.")
    print("================================================================\n")

    # Initial startup connection handshake event
    enqueue_event({
        "heartbeat": True,
        "startup": True,
        "deviceName": platform.node() or "Windows Workstation",
        "os": f"{platform.system()} {platform.release()} ({platform.architecture()[0]})",
        "agentVersion": "1.3.0",
        "samplingInterval": "500ms"
    })

    # Start background event dispatcher thread with resilient retries
    dispatcher = threading.Thread(target=event_dispatcher_loop, daemon=True)
    dispatcher.start()

    # Start foreground OS polling loop
    poller = threading.Thread(target=poll_os_loop, daemon=True)
    poller.start()

    # Optional local bridge server on 9876
    try:
        server = ThreadingHTTPServer(("0.0.0.0", PORT), BridgeHandler)
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped ChronoTrace Agent.")
    except Exception as e:
        # If port 9876 is bound or unavailable, keep worker threads running
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\nStopped ChronoTrace Agent.")
